using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class CameraFixedArea : MonoBehaviour
{
    [Header("카메라")]
    [SerializeField] private MainCamera mainCamera;
    [SerializeField] private Transform fixedPoint;

    [Header("이동 시간")]
    [SerializeField] private float moveDuration = 0.2f;

    private readonly HashSet<Collider2D> playerColliders = new HashSet<Collider2D>();

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!IsPlayer(other))
            return;

        if (!playerColliders.Add(other) || playerColliders.Count != 1)
            return;

        if (mainCamera != null && fixedPoint != null)
            mainCamera.EnterFixedArea(this, fixedPoint.position, moveDuration);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (!playerColliders.Remove(other) || playerColliders.Count > 0)
            return;

        if (mainCamera != null)
            mainCamera.ExitFixedArea(this, moveDuration);
    }

    private void OnDisable()
    {
        if (mainCamera != null && playerColliders.Count > 0)
            mainCamera.ExitFixedArea(this, moveDuration);

        playerColliders.Clear();
    }

    private bool IsPlayer(Collider2D other)
    {
        if (other.CompareTag("Player"))
            return true;

        return other.attachedRigidbody != null &&
               other.attachedRigidbody.CompareTag("Player");
    }

    private void Reset()
    {
        GetComponent<Collider2D>().isTrigger = true;
    }
}