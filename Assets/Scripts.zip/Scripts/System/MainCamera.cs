using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class MainCamera : MonoBehaviour
{
    private enum CameraState
    {
        Follow,
        MoveToFixed,
        Fixed,
        ReturnToFollow
    }

    [Header("플레이어 추적")]
    [SerializeField] private Transform target;
    [SerializeField] private float smoothSpeed = 1f; //카메라가 따라가는 부드러운 정도 (낮을수록 부드러움)
    [SerializeField] private Vector3 offset = new Vector3(0, 0, -10); //플레이어와의 거리 유지

    [Header("카메라 범위")]
    [SerializeField] private BoxCollider2D cameraBounds;

    [Header("피격 흔들림")]
    [SerializeField] private float hitShakeDuration = 0.2f;
    [SerializeField] private float hitShakeDistance = 0.25f;

    private Camera cameraComponent;

    private Vector3 followPosition;
    private Vector3 shakeOffset;

    private CameraState currentState = CameraState.Follow;
    private CameraFixedArea currentFixedArea;

    private Vector3 fixedPosition;
    private Vector3 transitionStartPosition;

    private float transitionDuration;
    private float transitionTimer;

    private Coroutine shakeCoroutine;

    private void Awake()
    {
        cameraComponent = GetComponent<Camera>();
    }

    private void Start()
    {
        if (target != null)
            followPosition = ClampPosition(target.position + offset);
    }

    private void LateUpdate()
    {
        if (target == null) return;

        //플레이어의 현재 위치에 오프셋을 더한 목표 좌표 계산
        Vector3 targetPosition = ClampPosition(target.position + offset);

        switch (currentState)
        {
            case CameraState.Follow:
                //일반 추적 중에만 카메라 범위 제한 적용
                followPosition = Vector3.Lerp(followPosition, targetPosition, smoothSpeed);
                followPosition = ClampPosition(followPosition);
                break;

            case CameraState.MoveToFixed:
                UpdateTransition(fixedPosition, CameraState.Fixed);
                break;

            case CameraState.Fixed:
                followPosition = fixedPosition;
                break;

            case CameraState.ReturnToFollow:
                UpdateTransition(targetPosition, CameraState.Follow);
                break;
        }

        //고정 카메라 이동 중에는 포인트 좌표를 범위로 자르지 않음
        Vector3 finalPosition = followPosition + shakeOffset;

        if (currentState == CameraState.Follow)
            finalPosition = ClampPosition(finalPosition);

        transform.position = finalPosition;
    }

    public void EnterFixedArea(CameraFixedArea fixedArea, Vector3 targetPosition, float duration)
    {
        currentFixedArea = fixedArea;
        fixedPosition = new Vector3(targetPosition.x, targetPosition.y, followPosition.z);

        StartTransition(CameraState.MoveToFixed, duration);
    }

    public void ExitFixedArea(CameraFixedArea fixedArea, float duration)
    {
        if (currentFixedArea != fixedArea)
            return;

        currentFixedArea = null;
        StartTransition(CameraState.ReturnToFollow, duration);
    }

    private void StartTransition(CameraState nextState, float duration)
    {
        transitionStartPosition = followPosition;
        transitionDuration = Mathf.Max(0f, duration);
        transitionTimer = 0f;
        currentState = nextState;
    }

    private void UpdateTransition(Vector3 targetPosition, CameraState nextState)
    {
        transitionTimer += Time.deltaTime;

        float progress = transitionDuration <= 0f
            ? 1f
            : Mathf.Clamp01(transitionTimer / transitionDuration);

        float smoothProgress = progress * progress * (3f - 2f * progress);

        followPosition = Vector3.Lerp(
            transitionStartPosition,
            targetPosition,
            smoothProgress
        );

        if (progress < 1f)
            return;

        followPosition = targetPosition;
        currentState = nextState;
    }

    //카메라 이동 범위 제한
    private Vector3 ClampPosition(Vector3 position)
    {
        if (cameraBounds == null) return position;

        Bounds bounds = cameraBounds.bounds;

        float halfHeight = cameraComponent.orthographicSize;
        float halfWidth = halfHeight * cameraComponent.aspect;

        float minX = bounds.min.x + halfWidth;
        float maxX = bounds.max.x - halfWidth;
        float minY = bounds.min.y + halfHeight;
        float maxY = bounds.max.y - halfHeight;

        position.x = minX <= maxX ? Mathf.Clamp(position.x, minX, maxX) : bounds.center.x;
        position.y = minY <= maxY ? Mathf.Clamp(position.y, minY, maxY) : bounds.center.y;

        return position;
    }

    //카메라 흔들림(피격 연출)
    public void PlayHitShake()
    {
        if (shakeCoroutine != null)
            StopCoroutine(shakeCoroutine);

        shakeCoroutine = StartCoroutine(HitShake());
    }

    //흔들림 처리
    private IEnumerator HitShake()
    {
        float elapsedTime = 0f;

        while (elapsedTime < hitShakeDuration)
        {
            elapsedTime += Time.unscaledDeltaTime;

            float progress = Mathf.Clamp01(elapsedTime / hitShakeDuration);

            float damping = (1f - progress) * (1f - progress);
            float shake = Mathf.Sin(progress * Mathf.PI * 6f) * hitShakeDistance * damping;

            shakeOffset = new Vector3(shake, 0f, 0f);

            yield return null;
        }

        shakeOffset = Vector3.zero;
        shakeCoroutine = null;
    }
}