using System;
using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class OcclusionArea : MonoBehaviour
{
    [Serializable]
    private class MaskData
    {
        public SpriteRenderer sourceRenderer;
        public SpriteMask spriteMask;

        [NonSerialized] public Transform originalParent;
    }

    [Header("가림 마스크")]
    [SerializeField] private MaskData[] maskData;

    private PlayerOcclusionVisual currentPlayer;

    private void Awake()
    {
        GetComponent<Collider2D>().isTrigger = true;

        foreach (MaskData data in maskData)
        {
            if (data.spriteMask != null)
                data.originalParent = data.spriteMask.transform.parent;
        }

        SetMaskActive(false);
    }

    private void LateUpdate()
    {
        if (currentPlayer == null) return;

        SyncMasks();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (currentPlayer != null) return;
        if (!other.TryGetComponent(out PlayerOcclusionVisual playerOcclusion)) return;
        if (playerOcclusion.MaskRoot == null)
        {
            Debug.LogError("PlayerOcclusionVisual의 Mask Root가 연결되지 않았습니다.", playerOcclusion);
            return;
        }

        currentPlayer = playerOcclusion;

        AttachMasks(currentPlayer.MaskRoot);
        SyncMasks();
        SetMaskActive(true);

        currentPlayer.EnterArea(this);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (currentPlayer == null) return;
        if (!other.TryGetComponent(out PlayerOcclusionVisual playerOcclusion)) return;
        if (playerOcclusion != currentPlayer) return;

        StopOcclusion();
    }

    //마스크를 플레이어 가림 표시 그룹에 연결
    private void AttachMasks(Transform maskRoot)
    {
        foreach (MaskData data in maskData)
        {
            if (data.spriteMask == null) continue;

            Transform maskTransform = data.spriteMask.transform;
            maskTransform.SetParent(maskRoot, true);
        }
    }

    //현재 스프라이트와 위치를 가림 마스크에 적용
    private void SyncMasks()
    {
        foreach (MaskData data in maskData)
        {
            if (data.sourceRenderer == null || data.spriteMask == null) continue;

            SpriteRenderer sourceRenderer = data.sourceRenderer;
            Transform sourceTransform = sourceRenderer.transform;
            Transform maskTransform = data.spriteMask.transform;

            data.spriteMask.sprite = sourceRenderer.sprite;

            maskTransform.SetPositionAndRotation(sourceTransform.position, sourceTransform.rotation);

            Vector3 sourceScale = sourceTransform.lossyScale;
            Vector3 parentScale = maskTransform.parent != null ? maskTransform.parent.lossyScale : Vector3.one;

            float flipX = sourceRenderer.flipX ? -1f : 1f;
            float flipY = sourceRenderer.flipY ? -1f : 1f;

            maskTransform.localScale = new Vector3(
                DivideScale(sourceScale.x, parentScale.x) * flipX,
                DivideScale(sourceScale.y, parentScale.y) * flipY,
                DivideScale(sourceScale.z, parentScale.z)
            );
        }
    }

    //마스크를 원래 부모로 복구
    private void RestoreMasks()
    {
        SetMaskActive(false);

        foreach (MaskData data in maskData)
        {
            if (data.spriteMask == null) continue;

            data.spriteMask.transform.SetParent(data.originalParent, true);
        }
    }

    //가림 표시 종료
    private void StopOcclusion()
    {
        PlayerOcclusionVisual playerOcclusion = currentPlayer;

        RestoreMasks();
        currentPlayer = null;

        playerOcclusion.ExitArea(this);
    }

    //플레이어 비활성화 시 마스크 복구
    public void ReleasePlayer(PlayerOcclusionVisual playerOcclusion)
    {
        if (currentPlayer != playerOcclusion) return;

        RestoreMasks();
        currentPlayer = null;
    }

    //가림 마스크 활성화 설정
    public void SetMaskActive(bool isActive)
    {
        foreach (MaskData data in maskData)
        {
            if (data.spriteMask != null)
                data.spriteMask.enabled = isActive;
        }
    }

    private static float DivideScale(float value, float parentValue)
    {
        return Mathf.Abs(parentValue) > Mathf.Epsilon ? value / parentValue : value;
    }

    private void OnDisable()
    {
        if (currentPlayer == null)
        {
            RestoreMasks();
            return;
        }

        StopOcclusion();
    }
}