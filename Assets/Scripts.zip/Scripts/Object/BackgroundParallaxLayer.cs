using UnityEngine;

[DefaultExecutionOrder(1000)]
public class BackgroundParallaxLayer : MonoBehaviour
{
    [Header("카메라")]
    [SerializeField] private Transform targetCamera;

    [Header("카메라 이동 추적 비율")]
    [SerializeField] private Vector2 followRatio = Vector2.one;

    private Vector3 startCameraPosition;
    private Vector3 startLayerPosition;

    private void Awake()
    {
        if (targetCamera == null && Camera.main != null)
            targetCamera = Camera.main.transform;

        if (targetCamera == null)
            return;

        startCameraPosition = targetCamera.position;
        startLayerPosition = transform.position;
    }

    private void LateUpdate()
    {
        if (targetCamera == null)
            return;

        Vector3 cameraMovement = targetCamera.position - startCameraPosition;

        transform.position = new Vector3(
            startLayerPosition.x + cameraMovement.x * followRatio.x,
            startLayerPosition.y + cameraMovement.y * followRatio.y,
            startLayerPosition.z
        );
    }
}