using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Animator))]
public class TreeAnimationRandomizer : MonoBehaviour
{
    //시작 딜레이
    private const float MinStartDelay = 0f;
    private const float MaxStartDelay = 0.5f;

    //애니메이션 속도
    private const float MinAnimationSpeed = 0.8f;
    private const float MaxAnimationSpeed = 1.2f;

    private static readonly int CycleOffsetHash = Animator.StringToHash("CycleOffset");

    private Animator animator;

    private void Awake()
    {
        animator = GetComponent<Animator>();

        animator.SetFloat(CycleOffsetHash, Random.value);
        animator.speed = 0f;
    }

    private IEnumerator Start()
    {
        float startDelay = Random.Range(MinStartDelay, MaxStartDelay);

        if (startDelay > 0f)
        {
            yield return new WaitForSeconds(startDelay);
        }

        animator.speed = Random.Range(
            MinAnimationSpeed,
            MaxAnimationSpeed
        );
    }
}