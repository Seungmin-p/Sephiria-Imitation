using UnityEngine;

public class BreakableObject : MonoBehaviour, IDamageable
{
    [System.Serializable]
    private struct FragmentData
    {
        public FragmentEffect prefab;
        [Min(1)] public int count;
    }

    [Header("파괴 전/후 오브젝트")]
    [SerializeField] private GameObject breakBefore;
    [SerializeField] private GameObject breakAfter;

    [Header("파괴 파편")]
    [SerializeField] private FragmentData[] fragments;

    private bool isBroken;
    
    //count 기본값 1로 설정
    private void OnValidate()
    {
        if (fragments == null) return;

        for (int i = 0; i < fragments.Length; i++)
        {
            FragmentData fragmentData = fragments[i];

            if (fragmentData.count < 1)
            {
                fragmentData.count = 1;
                fragments[i] = fragmentData;
            }
        }
    }

    private void Awake()
    {
        if (breakBefore != null)
            breakBefore.SetActive(true);

        if (breakAfter != null)
            breakAfter.SetActive(false);
    }

    //피격 및 파괴 처리
    public DamageResult TakeDamage(AttackData attackData)
    {
        //이미 파괴되었거나 플레이어의 공격이 아니라면 패스
        if (isBroken || attackData.source != DamageSource.Player)
        {
            return new DamageResult(
                0f,
                false,
                DamageResult.HitResultType.Ignored,
                attackData.element,
                attackData.source
            );
        }

        Break();

        return new DamageResult(
            0f,
            false,
            DamageResult.HitResultType.ObjectHit,
            attackData.element,
            attackData.source
        );
    }

    //오브젝트 파괴
    private void Break()
    {
        isBroken = true;

        SpawnFragments();

        if (breakBefore != null)
            breakBefore.SetActive(false);

        if (breakAfter != null)
            breakAfter.SetActive(true);
    }

    //파괴 파편 생성
    private void SpawnFragments()
    {
        if (fragments == null) return;

        Vector3 spawnPosition = transform.position;

        foreach (FragmentData fragmentData in fragments)
        {
            if (fragmentData.prefab == null) continue;

            for (int i = 0; i < fragmentData.count; i++)
            {
                float randomAngle = Random.Range(0f, 360f);
                Vector2 direction = Quaternion.Euler(0f, 0f, randomAngle) * Vector2.right;

                FragmentEffect fragment = Instantiate(fragmentData.prefab, spawnPosition, Quaternion.identity);
                fragment.Initialize(direction);
            }
        }
    }
}