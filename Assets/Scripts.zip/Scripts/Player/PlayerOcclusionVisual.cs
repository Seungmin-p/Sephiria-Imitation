using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerOcclusionVisual : MonoBehaviour
{
    [Serializable]
    private class RendererPair
    {
        public SpriteRenderer sourceRenderer;
        public SpriteRenderer occlusionRenderer;
    }

    [Header("가림 표시")]
    [SerializeField, Range(0f, 1f)] private float occlusionAlpha = 0.4f;
    [SerializeField] private RendererPair[] rendererPairs;
    [SerializeField] private SpriteRenderer shadowRenderer;
    [SerializeField] private Transform maskRoot;

    private readonly HashSet<OcclusionArea> activeAreas = new();

    private bool isOccluded;
    private bool shadowWasEnabled;
    
    public Transform MaskRoot => maskRoot;

    private void Awake()
    {
        foreach (RendererPair rendererPair in rendererPairs)
        {
            if (rendererPair.occlusionRenderer == null) continue;

            rendererPair.occlusionRenderer.maskInteraction = SpriteMaskInteraction.VisibleInsideMask;
            rendererPair.occlusionRenderer.enabled = false;
        }
    }

    private void LateUpdate()
    {
        if (!isOccluded) return;

        SyncRenderers();
    }

    //가림 영역 진입
    public void EnterArea(OcclusionArea occlusionArea)
    {
        if (occlusionArea == null || !activeAreas.Add(occlusionArea)) return;
        if (activeAreas.Count == 1) StartOcclusion();
    }

    //가림 영역 이탈
    public void ExitArea(OcclusionArea occlusionArea)
    {
        if (occlusionArea == null || !activeAreas.Remove(occlusionArea)) return;
        if (activeAreas.Count == 0) StopOcclusion();
    }

    //가림 표시 시작
    private void StartOcclusion()
    {
        isOccluded = true;

        if (shadowRenderer != null)
        {
            shadowWasEnabled = shadowRenderer.enabled;
            shadowRenderer.enabled = false;
        }

        SyncRenderers();
    }

    //가림 표시 종료
    private void StopOcclusion()
    {
        isOccluded = false;
        SetOcclusionRenderersActive(false);

        if (shadowRenderer != null)
            shadowRenderer.enabled = shadowWasEnabled;
    }

    //원본 렌더러 상태를 가림 표시용 렌더러에 적용
    private void SyncRenderers()
    {
        foreach (RendererPair rendererPair in rendererPairs)
        {
            SpriteRenderer sourceRenderer = rendererPair.sourceRenderer;
            SpriteRenderer occlusionRenderer = rendererPair.occlusionRenderer;

            if (sourceRenderer == null || occlusionRenderer == null) continue;

            Transform sourceTransform = sourceRenderer.transform;
            Transform occlusionTransform = occlusionRenderer.transform;

            occlusionTransform.SetPositionAndRotation(sourceTransform.position, sourceTransform.rotation);
            occlusionTransform.localScale = sourceTransform.lossyScale;

            occlusionRenderer.sprite = sourceRenderer.sprite;
            occlusionRenderer.flipX = sourceRenderer.flipX;
            occlusionRenderer.flipY = sourceRenderer.flipY;

            Color sourceColor = sourceRenderer.color;
            sourceColor.a *= occlusionAlpha;

            occlusionRenderer.color = sourceColor;
            occlusionRenderer.enabled = sourceRenderer.enabled;
        }
    }

    //가림 표시용 렌더러 활성화 설정
    private void SetOcclusionRenderersActive(bool isActive)
    {
        foreach (RendererPair rendererPair in rendererPairs)
        {
            if (rendererPair.occlusionRenderer != null)
                rendererPair.occlusionRenderer.enabled = isActive;
        }
    }

    private void OnDisable()
    {
        foreach (OcclusionArea occlusionArea in activeAreas)
        {
            if (occlusionArea != null)
                occlusionArea.ReleasePlayer(this);
        }

        activeAreas.Clear();

        if (isOccluded)
            StopOcclusion();
    }
}